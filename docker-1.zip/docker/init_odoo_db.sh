#!/bin/sh
set -eu
# Use a separate CREATEDB role for Odoo; keep the bootstrap superuser internal.
if [ "$ODOO_DB_USER" = postgres ]; then
    echo 'ODOO_DB_USER must differ from postgres.' >&2
    exit 1
fi
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname postgres <<'SQL'
\getenv odoo_user ODOO_DB_USER
\getenv odoo_password ODOO_DB_PASSWORD
SELECT format('CREATE ROLE %I LOGIN CREATEDB NOSUPERUSER NOCREATEROLE PASSWORD %L',
              :'odoo_user', :'odoo_password') \gexec
SQL
