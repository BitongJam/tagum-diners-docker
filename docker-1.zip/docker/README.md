# Odoo 18 and PostgreSQL 16 with Docker Compose

This setup builds Ubuntu 24.04 / Python 3.12 for Intel/AMD (`linux/amd64`).
It installs the cloned Odoo 18 requirements, patched-Qt wkhtmltopdf, PostgreSQL
16 client tools (`pg_dump`, `pg_restore`, `psql`), fonts and asset tools.
Nginx proxies HTTP and websocket requests to Odoo. Database/module initialization
remains manual.

## Configure and start

Copy this entire `docker/` folder to the server (including hidden files). Run
commands from inside the copied folder using Docker Engine and a recent Docker Compose
with environment-backed build secret support:

```bash
if [ ! -f .env ]; then cp .env.example .env; fi
chmod 600 .env
```

Edit `.env` with your GitHub HTTPS repository URL and passwords. A private
repository needs a GitHub token with read access to its contents. Leave
`GITHUB_BRANCH` empty to clone the repository's default branch; Odoo always
uses upstream branch `18.0`. For a public repository, leave `GITHUB_TOKEN` empty.
Use single quotes around `.env` password values containing `$` or `#`.
Do not put credentials in the repository URL.

```bash
docker compose build odoo
docker compose up -d
docker compose ps
docker compose logs -f odoo
```

Open `http://localhost:18069/web/database/manager`. Use
`admin_passwd` from `odoo.conf` to create or restore a database through Odoo. The
PostgreSQL bootstrap database is `postgres`; it is not an initialized Odoo
database. Install the Tagum Diners application manually after database creation,
or restore an existing backup with its matching addons available.

Nginx publishes `127.0.0.1:18069` by default, so access requires an explicit
port and stays on the local host. Set `NGINX_PORT` to another unused host port
if 18069 is already occupied. For deliberate remote access, set
`NGINX_BIND_ADDRESS` to the server interface or `0.0.0.0` and use its IP
with the chosen port. Existing `.env` files
should replace `ODOO_BIND_ADDRESS`/`ODOO_PORT` with these Nginx variables.
Odoo 8069 (HTTP), Odoo 8072 (websocket) and PostgreSQL remain internal.
The database manager remains enabled.

`nginx.conf` follows the [Odoo 18 reverse-proxy example](https://www.odoo.com/documentation/18.0/administration/on_premise/deploy.html#https):
`/websocket` goes to `odoo:8072`, and all other application requests go to
`odoo:8069`. Both use the same public URL and port. Upgrade headers and
720-second proxy timeouts support long-lived websocket connections. Docker
DNS resolves Odoo again after container recreation. Nginx accepts uploads
up to 100 MB; adjust `client_max_body_size` for larger database restores.

This development endpoint uses HTTP. For an internet-facing deployment, add
a domain, certificates and HTTPS termination as described in Odoo’s example.
The supplied headers assume clients connect directly to this Nginx; an outer
TLS proxy requires explicit trusted-proxy/header configuration.

Set `proxy_mode = True`, `workers = 2`, `max_cron_threads = 1` and
`gevent_port = 8072` in existing host `odoo.conf` files as in the updated
example. Nonzero workers start the dedicated gevent listener; `workers = 0`
does not provide this separate websocket port. Tune worker counts to available
CPU/RAM. Nginx starts after Odoo’s HTTP healthcheck succeeds.

## Files and configuration

- Tagum repository runtime addons: `/opt/tagum_diner/tagum_diners/my_addons`.
- Odoo checkout: `/opt/tagum_diner/odoo`.
- Python virtual environment: `/opt/tagum_diner/venv`.
- Host config: `./odoo.conf`, bind-mounted as `/etc/odoo/odoo.conf`.
- Filestore, sessions and Odoo data: `/var/lib/odoo` (named `odoo_data` volume).
- PostgreSQL data: `/var/lib/postgresql/data` (named `postgres_data` volume).

The host file `./odoo.conf` mounts read-only at `/etc/odoo/odoo.conf`.
**Odoo uses that exact file directly. No runtime copy is generated.**

Before starting, copy the example if needed and edit it:

```bash
if [ ! -f odoo.conf ]; then cp odoo.conf.example odoo.conf; fi
```

Set `admin_passwd` to your database-manager master password. Set `db_user` and
`db_password` to match `ODOO_DB_USER` and `ODOO_DB_PASSWORD` in `.env`.
Use `db_host = postgres` and `db_port = 5432`. Odoo does not expand environment
variables in this file. It must be readable by the container's Odoo user; use
mode 644 within a protected deployment directory. This private file is ignored
by Git; only the sanitized example is tracked.

After changing the config, recreate Odoo to pick up atomic editor saves:

```bash
docker compose up -d --force-recreate odoo
```

Change the master password in this host file; a read-only mount prevents saving
master-password changes through the database-manager UI. Database creation,
backup and restore remain available. PostgreSQL credentials in `.env` initialize
its role only on an empty PostgreSQL volume; editing them does not change an
existing role's password.

Compose reads `.env` and passes only required runtime values to each service.
The GitHub token is passed as a BuildKit secret; it is not a build argument or
runtime environment variable. Git history and project engineering documents
are removed from the cloned image source. The build context is allowlisted.
The image still contains private application code; keep it private.

The initial PostgreSQL script creates an Odoo role with `CREATEDB`, without
superuser or role administration privileges. `POSTGRES_PASSWORD` belongs to
the separate bootstrap administrator. Initialization runs only on an empty
PostgreSQL volume. Changing database credentials in `.env` does not change
existing PostgreSQL roles: update the actual role password before recreating
services with new settings. Keep the Compose project name/directory stable
so subsequent deployments use the same volumes.

## Updates and persistence

Recreating containers preserves both named volumes:

```bash
docker compose down
docker compose up -d
```

To fetch new code, increment `SOURCE_REFRESH` in `.env`, then:

```bash
docker compose build odoo
docker compose up -d
```

Build caching otherwise reuses the existing clone, even when GitHub changes.
The image records resolved commit IDs in `/opt/tagum_diner/odoo-revision` and
`/opt/tagum_diner/tagum-diners-revision`. No pull happens at container startup.
Building a new image does not upgrade installed Odoo modules. Back up first
and perform required module upgrades explicitly for the target database.
Do not run `docker compose down -v` unless you intend to delete both volumes.

For backups, use the database manager's ZIP backup option to include the
filestore. A database-only dump does not preserve attachments. Store backups
outside the Docker volumes and verify restoration separately.

## Upstream references

- [Odoo's Noble Dockerfile and patched-Qt package](https://github.com/odoo/docker/blob/master/18.0/Dockerfile)
- [Odoo 18 Python requirements](https://github.com/odoo/odoo/blob/18.0/requirements.txt)
- [Docker build secrets](https://docs.docker.com/build/building/secrets/)

## Standalone deployment files

Everything needed to build and start the services is in this directory:
`Dockerfile`, `compose.yaml`, `.dockerignore`, `.env.example`, `clone_project.py`,
`entrypoint.py`, `init_odoo_db.sh`, `nginx.conf`, and `odoo.conf.example`. Application source and its production
configuration template are fetched from GitHub during the image build. No parent
folder, local Odoo checkout, or local addon source is required on the server.
Copy the folder before its first startup, then create the server's private `.env`
from `.env.example`. Keep any existing private `.env` protected if transferring it.
Generated `odoo.conf` files contain credentials; copy them only when deliberately
moving an existing deployment. Database/filestore Docker volumes live on their
Docker host and are not copied with this directory; transfer data through a
verified backup/restore when moving hosts.

If moving an existing deployment on the same Docker host, keep its original
Compose project name (`docker compose -p ORIGINAL_NAME ...`, or set
`COMPOSE_PROJECT_NAME` in `.env`) so its existing named volumes are selected.

The optional configuration unit tests run without the rest of the project:

```bash
python3 -m unittest discover -s . -p 'test_*.py'
```

Visible Playwright acceptance tests are maintained in the development repository's
`scripts/browser_tests/` directory. They run on the developer computer and are not
required for server deployment.

## Proxy validation

```bash
docker compose config --quiet
docker compose run --rm --no-deps nginx nginx -t
docker compose up -d
curl --fail http://localhost:18069/nginx-health
curl --fail http://localhost:18069/web/database/manager
docker compose logs --tail=100 nginx odoo
```

After signing in to an initialized database, check the browser Network tab
for `/websocket` upgrading with status **101 Switching Protocols**. A plain
HTTP request without upgrade headers does not establish a websocket.
After editing `nginx.conf`, recreate Nginx to pick up bind-mount replacements:
`docker compose up -d --force-recreate nginx`.
