"""Render the repository config with Compose settings, then start Odoo."""

import configparser
import os
import pwd
from pathlib import Path
import sys
import time

import psycopg2


ROOT = Path('/opt/tagum_diner')
OUTPUT_DIR = Path('/etc/odoo')


def prepare_config_directory():
    """Drop privileges without changing the read-only host configuration."""
    if os.geteuid() == 0:
        account = pwd.getpwnam('odoo')
        os.initgroups(account.pw_name, account.pw_gid)
        os.setgid(account.pw_gid)
        os.setuid(account.pw_uid)
        os.environ['HOME'] = account.pw_dir


def main():
    prepare_config_directory()
    source = OUTPUT_DIR / 'odoo.conf'
    if source.is_symlink() or not source.is_file():
        raise SystemExit('Mount a readable odoo.conf at /etc/odoo/odoo.conf.')
    config = configparser.RawConfigParser()
    config.read(source)
    settings = {}
    for name in ('admin_passwd', 'db_host', 'db_port', 'db_user', 'db_password'):
        value = config.get('options', name, fallback='').strip()
        if not value or value.startswith('REPLACE_ME'):
            raise SystemExit(f'Set {name} in your host odoo.conf before starting.')
        settings[name] = value
    deadline = time.monotonic() + 60
    while True:
        try:
            connection = psycopg2.connect(
                host=settings['db_host'], port=settings['db_port'],
                user=settings['db_user'], password=settings['db_password'],
                dbname='postgres', connect_timeout=3,
            )
            connection.close()
            break
        except psycopg2.OperationalError:
            if time.monotonic() >= deadline:
                raise SystemExit('PostgreSQL unavailable after 60 seconds; check odoo.conf credentials and database logs.')
            time.sleep(2)
    os.execv(sys.executable, [
        sys.executable, str(ROOT / 'odoo/odoo-bin'), '-c', str(source),
        *sys.argv[1:],
    ])


if __name__ == '__main__':
    main()
