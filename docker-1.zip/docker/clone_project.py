"""Clone GitHub source without persisting its build-only credential."""

import os
from pathlib import Path
import shutil
import subprocess
import tempfile
from urllib.parse import urlsplit


url = os.environ.get('GITHUB_REPO_URL', '')
parsed = urlsplit(url)
if (parsed.scheme != 'https' or parsed.hostname != 'github.com'
        or parsed.username or parsed.password or parsed.query or parsed.fragment
        or parsed.port or len(parsed.path.strip('/').split('/')) != 2):
    raise SystemExit('GITHUB_REPO_URL must be an HTTPS GitHub owner/repository URL without credentials.')

root = Path('/opt/tagum_diner')
root.mkdir(parents=True, exist_ok=True)
target = root / 'tagum_diners'
environment = dict(os.environ, GIT_TERMINAL_PROMPT='0')
with tempfile.TemporaryDirectory() as directory:
    askpass = Path(directory) / 'askpass'
    askpass.write_text(
        '#!/bin/sh\n'
        'case "$1" in\n'
        '  *Username*) printf "%s\\n" x-access-token ;;\n'
        '  *Password*) cat /run/secrets/github_token ;;\n'
        'esac\n'
    )
    askpass.chmod(0o700)
    environment['GIT_ASKPASS'] = str(askpass)
    command = ['git', '-c', 'credential.helper=', 'clone', '--depth', '1', '--single-branch']
    branch = os.environ.get('GITHUB_BRANCH')
    if branch:
        command.extend(['--branch', branch])
    command.extend(['--', url, str(target)])
    subprocess.run(command, env=environment, check=True)

revision = subprocess.check_output(['git', '-C', str(target), 'rev-parse', 'HEAD'], text=True)
(root / 'tagum-diners-revision').write_text(revision)
shutil.rmtree(target / '.git')
# Only runtime addon source belongs in the image, not private engineering docs.
for child in target.iterdir():
    if child.name != 'my_addons':
        if child.is_dir() and not child.is_symlink():
            shutil.rmtree(child)
        else:
            child.unlink()
for path in list(target.rglob('__pycache__')):
    shutil.rmtree(path)
for path in target.rglob('MODULE.md'):
    path.unlink()
# Never carry local credential files from the cloned repository into the image.
for path in (target / 'my_addons' / 'config').glob('*'):
    if path.is_file() and path.suffix == '.conf':
        path.unlink()
