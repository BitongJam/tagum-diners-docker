"""Check direct read-only configuration startup without a real database."""

import importlib.util
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import MagicMock, patch


class TestEntrypoint(unittest.TestCase):
    def setUp(self):
        database = types.ModuleType('psycopg2')
        database.OperationalError = RuntimeError
        database.connect = MagicMock()
        self.database = database
        spec = importlib.util.spec_from_file_location('entrypoint', Path(__file__).with_name('entrypoint.py'))
        self.module = importlib.util.module_from_spec(spec)
        with patch.dict(sys.modules, psycopg2=database):
            spec.loader.exec_module(self.module)
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.module.OUTPUT_DIR = Path(self.directory.name)
        self.source = self.module.OUTPUT_DIR / 'odoo.conf'
        self.source.write_text('[options]\nadmin_passwd = master%secret\ndb_host = postgres\ndb_port = 5432\ndb_user = odoo\ndb_password = db%secret\n')
        privileges = patch.object(self.module, 'prepare_config_directory')
        privileges.start()
        self.addCleanup(privileges.stop)

    def test_uses_exact_mounted_file_without_modifying_it(self):
        before = self.source.read_bytes()
        self.source.chmod(0o444)
        with patch.object(self.module.os, 'execv') as execute, patch.object(sys, 'argv', ['entrypoint']):
            self.module.main()
        self.assertEqual(self.source.read_bytes(), before)
        self.assertEqual(execute.call_args.args[1][-2:], ['-c', str(self.source)])
        self.database.connect.assert_called_once_with(
            host='postgres', port='5432', user='odoo', password='db%secret',
            dbname='postgres', connect_timeout=3,
        )
        self.assertEqual(list(self.module.OUTPUT_DIR.iterdir()), [self.source])

    def test_placeholder_credentials_rejected(self):
        self.source.write_text(Path(__file__).with_name('odoo.conf.example').read_text())
        with self.assertRaises(SystemExit):
            self.module.main()
        self.database.connect.assert_not_called()

    def test_missing_mount_rejected(self):
        self.source.unlink()
        with self.assertRaises(SystemExit):
            self.module.main()
        self.database.connect.assert_not_called()


if __name__ == '__main__':
    unittest.main()
